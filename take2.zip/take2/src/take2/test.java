package take2;


import java.io.FileNotFoundException;
import java.util.ArrayList;


public class test { 
	
	String[] name = new String[2];
	
	public static void main(String args[]) throws FileNotFoundException
	{
		Calculations test = new Calculations();
		ArrayList<Student> s = test.getAverage();
		for(int i = 0; i < s.size(); i++)
		{
		s.get(i).getName();
		System.out.println(s.get(i).getQuizAverage());
		System.out.println(s.get(i).getAssignmentAverage());
		}
	}
}
